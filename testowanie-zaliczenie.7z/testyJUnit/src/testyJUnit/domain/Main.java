package testyJUnit.domain;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
